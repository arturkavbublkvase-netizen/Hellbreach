# Hellbreach 1.0.1 — Paper/Leaf 1.21.11, Java 21

Сборка: `gradle build` → `build/libs/Hellbreach-1.0.1.jar` в папку plugins.
Команда: `/hellbreach` (взгляд) | `x y z` | `мир x y z` | `cancel` | `reload` (алиасы rift, razlom).
Права: hellbreach.use / hellbreach.admin / hellbreach.bypass.

Обязательно для зрителей издалека — spigot.yml:
  world-settings.default.entity-tracking-range.display: 192-256   (по умолчанию 128)
Ресурспак и сторонние библиотеки не нужны: всё на BlockDisplay и частицах.
Защита территорий работает через EntityExplodeEvent (WorldGuard, GriefPrevention и т.п.).
