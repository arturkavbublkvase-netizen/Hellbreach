package dev.hellbreach;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Щупальце = цепочка BlockDisplay, идущая вдоль заранее построенной сплайн-траектории «от разлома до точки удара»
 * (follow-the-leader): кончик ползёт по пути, тело тянется следом. Это даёт «выход из дыры» без складывания цепи,
 * а втягивание — тот же путь в обратную сторону.
 * Масса: тело сглаживается (follow) и отстаёт от кончика; поверх идёт затухающая волна-извивание.
 * Все сущности привязаны к одной точке-якорю, двигаются только трансформацией (интерполяция на клиенте).
 */
final class TentacleRig {
    private static final Vector3d UP = new Vector3d(0, 1, 0);

    /** Траектория Catmull-Rom с таблицей длин дуги. */
    static final class PathCurve {
        final Vector3d[] pts;
        final double[] cum;
        final double total;

        PathCurve(List<Vector3d> c, int perSeg) {
            List<Vector3d> out = new ArrayList<>();
            int m = c.size();
            for (int i = 0; i < m - 1; i++) {
                Vector3d p0 = c.get(Math.max(i - 1, 0)), p1 = c.get(i), p2 = c.get(i + 1), p3 = c.get(Math.min(i + 2, m - 1));
                for (int k = 0; k < perSeg; k++) {
                    double t = k / (double) perSeg, t2 = t * t, t3 = t2 * t;
                    out.add(new Vector3d(
                            cr(p0.x, p1.x, p2.x, p3.x, t, t2, t3),
                            cr(p0.y, p1.y, p2.y, p3.y, t, t2, t3),
                            cr(p0.z, p1.z, p2.z, p3.z, t, t2, t3)));
                }
            }
            out.add(new Vector3d(c.get(m - 1)));
            pts = out.toArray(new Vector3d[0]);
            cum = new double[pts.length];
            for (int i = 1; i < pts.length; i++) cum[i] = cum[i - 1] + pts[i].distance(pts[i - 1]);
            total = cum[cum.length - 1];
        }

        private static double cr(double a, double b, double c, double d, double t, double t2, double t3) {
            return 0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
        }

        /** Точка на расстоянии sArc от начала; до начала и после конца — зажимается. */
        void at(double sArc, Vector3d out) {
            if (sArc <= 0) { out.set(pts[0]); return; }
            if (sArc >= total) { out.set(pts[pts.length - 1]); return; }
            int i = Arrays.binarySearch(cum, sArc);
            if (i < 0) i = -i - 2;
            i = Math.min(i, pts.length - 2);
            double span = cum[i + 1] - cum[i];
            double f = span < 1e-9 ? 0 : (sArc - cum[i]) / span;
            out.set(pts[i]).lerp(pts[i + 1], f);
        }
    }

    private final DisplayKit kit;
    private final Settings s;
    private final PathCurve curve;
    private final int n;
    private final double segLen, planeY;
    private final Vector3d anchor;
    private final BlockDisplay[] segs;
    private final Vector3d[] base, tgt, cur;
    private final boolean[] hidden;
    private boolean init;
    private final Vector3d t1 = new Vector3d(), n1 = new Vector3d(), n2 = new Vector3d();

    TentacleRig(DisplayKit kit, Settings s, Vector3d rift, Vector3d tip, boolean flip) {
        this.kit = kit;
        this.s = s;
        this.n = s.segments;

        Vector3d d = new Vector3d(tip).sub(rift);
        double dist = d.length();
        Vector3d hor = new Vector3d(d.x, 0, d.z);
        Vector3d side = hor.lengthSquared() < 1e-4 ? new Vector3d(1, 0, 0) : new Vector3d(-hor.z, 0, hor.x).normalize();
        double sg = flip ? -1 : 1;

        List<Vector3d> ctrl = new ArrayList<>();
        ctrl.add(new Vector3d(rift).add(0, 4, 0));                                  // спрятано за провалом
        ctrl.add(new Vector3d(rift).add(0, -7, 0));                                 // выходит прямо вниз
        ctrl.add(new Vector3d(rift).fma(0.38, d).fma(0.24 * dist * sg, side));      // S-образный изгиб
        ctrl.add(new Vector3d(rift).fma(0.72, d).fma(-0.10 * dist * sg, side));
        ctrl.add(new Vector3d(tip).add(0, 10, 0));                                  // заход на цель сверху
        ctrl.add(new Vector3d(tip));
        this.curve = new PathCurve(ctrl, 40);

        double bodyLen = curve.total + 8;              // чуть длиннее пути: корень всегда остаётся в провале
        this.segLen = bodyLen / n;
        this.anchor = new Vector3d(rift).add(tip).mul(0.5);
        this.planeY = rift.y + s.baseWidth;
        this.segs = new BlockDisplay[n];
        this.base = new Vector3d[n + 1];
        this.tgt = new Vector3d[n + 1];
        this.cur = new Vector3d[n + 1];
        for (int i = 0; i <= n; i++) {
            base[i] = new Vector3d();
            tgt[i] = new Vector3d();
            cur[i] = new Vector3d();
        }
        this.hidden = new boolean[n];
        Arrays.fill(hidden, true);
    }

    double pathLength() {
        return curve.total;
    }

    /** Спавнит сегменты [from, to) — порциями, чтобы не было пика в один тик. */
    void spawn(World w, int from, int to) {
        Location al = new Location(w, anchor.x, anchor.y, anchor.z);
        for (int i = from; i < to && i < n; i++) {
            boolean node = isNode(i);
            segs[i] = kit.block(al, node ? s.nodeMat : s.fleshMat, DisplayKit.tiny(new Vector3f()), node);
        }
    }

    private boolean isNode(int i) {
        return s.nodeEvery > 0 && i % s.nodeEvery == s.nodeEvery - 1;
    }

    private float width(int i) {
        double f = Math.pow(i / (double) (n - 1), 0.85);
        double w = s.baseWidth + (s.tipWidth - s.baseWidth) * f;
        return (float) (isNode(i) ? w * 1.25 : w);
    }

    /**
     * @param sTip позиция кончика вдоль пути (0 = у провала, pathLength = точка удара)
     * @param wave амплитуда извивания 0..1
     * @param time номер тика (фаза волны)
     * @param dur  длительность клиентской интерполяции
     */
    void step(double sTip, double wave, double time, int dur) {
        for (int j = 0; j <= n; j++) curve.at(sTip - (n - j) * segLen, base[j]);

        for (int j = 0; j <= n; j++) {
            tgt[j].set(base[j]);
            double sj = sTip - (n - j) * segLen;
            if (wave > 1e-3 && sj > 0) {
                int a = Math.max(0, j - 1), b = Math.min(n, j + 1);
                t1.set(base[b]).sub(base[a]);
                if (t1.lengthSquared() > 1e-6) {
                    t1.normalize();
                    n1.set(t1).cross(UP);
                    if (n1.lengthSquared() < 1e-6) n1.set(1, 0, 0); else n1.normalize();
                    n2.set(t1).cross(n1);
                    double amp = wave * s.waveAmp * (0.25 + 0.75 * j / n) * Math.min(1.0, sj / 14.0);
                    double ph = time * 0.22 - j * 0.55;
                    tgt[j].fma(Math.sin(ph) * amp, n1).fma(Math.cos(ph * 0.8) * amp * 0.6, n2);
                }
            }
            if (!init) cur[j].set(tgt[j]);
            else cur[j].lerp(tgt[j], j == n ? 1.0 : s.follow);   // кончик точный, тело запаздывает → «масса»
        }
        init = true;

        for (int i = 0; i < n; i++) {
            if (segs[i] == null) continue;
            Vector3d a = cur[i], b = cur[i + 1];
            boolean hid = a.y > planeY && b.y > planeY;          // целиком за плоскостью разлома — не шлём пакеты
            if (hid && hidden[i]) continue;
            hidden[i] = hid;

            double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            Vector3f center = new Vector3f(
                    (float) ((a.x + b.x) / 2 - anchor.x),
                    (float) ((a.y + b.y) / 2 - anchor.y),
                    (float) ((a.z + b.z) / 2 - anchor.z));
            Transformation tr;
            if (len < 0.05) {
                tr = DisplayKit.tiny(center);
            } else {
                float w = width(i);
                Quaternionf q = new Quaternionf()
                        .rotationTo(0f, 1f, 0f, (float) (dx / len), (float) (dy / len), (float) (dz / len))
                        .rotateY((float) (i * 0.4 + time * 0.015));      // лёгкая «закрутка» граней вдоль тела
                tr = DisplayKit.box(center, q, new Vector3f(w, (float) (len * 1.2 + 0.15), w));
            }
            kit.apply(segs[i], tr, dur);
        }
    }

    void remove() {
        for (BlockDisplay d : segs) kit.kill(d);
    }
}
