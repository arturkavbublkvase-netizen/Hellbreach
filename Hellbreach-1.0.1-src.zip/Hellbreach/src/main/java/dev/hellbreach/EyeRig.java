package dev.hellbreach;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.BlockDisplay;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Жёлтый глаз из ~35 плоских блок-дисплеев: «миндалина» склеры (полосы), радужка, вертикальный зрачок и два века.
 * Лежит горизонтально под плоскостью разлома и смотрит вниз, на землю.
 * Локальные оси: x — длинная ось глаза, z — короткая, y — «к земле» (минус).
 */
final class EyeRig {
    private static final Quaternionf IDENT = new Quaternionf();
    private static final int SCLERA = 0, GAZE = 1, LID_TOP = 2, LID_BOTTOM = 3;

    private static final class Part {
        BlockDisplay d;
        float cx, cy, cz, sx, sy, sz;
        int kind;
    }

    private final List<Part> parts = new ArrayList<>();

    void build(DisplayKit kit, Settings s, Location c) {
        float a = (float) (s.eyeWidth / 2), b = (float) (s.eyeHeight / 2);

        // склера — эллипс из 15 полос вдоль оси x
        int n = 15;
        float step = 2 * b / n;
        for (int i = 0; i < n; i++) {
            float z = -b + (i + 0.5f) * step;
            float u = Math.abs(z) / b;
            float hw = a * (float) Math.sqrt(Math.max(0.03, 1 - u * u));
            add(kit, c, s.eyeScleraMat, 0, 0, z, 2 * hw, 0.5f, step + 0.05f, SCLERA);
        }
        // радужка — круг радиуса ri
        float ri = b * 0.8f;
        n = 9;
        step = 2 * ri / n;
        for (int i = 0; i < n; i++) {
            float z = -ri + (i + 0.5f) * step;
            float hw = (float) Math.sqrt(Math.max(0.05, ri * ri - z * z));
            add(kit, c, s.eyeIrisMat, 0, -0.45f, z, 2 * hw, 0.5f, step + 0.05f, GAZE);
        }
        // зрачок — вертикальная щель (узкая по x, длинная по z)
        float pw = ri * 0.26f, pl = ri * 0.98f;
        n = 11;
        step = 2 * pl / n;
        for (int i = 0; i < n; i++) {
            float z = -pl + (i + 0.5f) * step;
            float u = Math.abs(z) / pl;
            float hw = Math.max(0.15f, pw * (float) Math.sqrt(Math.max(0.0, 1 - u * u)));
            add(kit, c, s.eyePupilMat, 0, -0.9f, z, 2 * hw, 0.5f, step + 0.05f, GAZE);
        }
        // веки: sz хранит полувысоту прикрытия B
        float lw = 2 * a + 3, bb = b + 1.2f;
        add(kit, c, s.eyeLidMat, 0, -1.5f, 0, lw, 0.5f, bb, LID_TOP);
        add(kit, c, s.eyeLidMat, 0, -1.5f, 0, lw, 0.5f, bb, LID_BOTTOM);
    }

    private void add(DisplayKit kit, Location c, Material m, float cx, float cy, float cz,
                     float sx, float sy, float sz, int kind) {
        Part p = new Part();
        p.cx = cx; p.cy = cy; p.cz = cz; p.sx = sx; p.sy = sy; p.sz = sz; p.kind = kind;
        p.d = kit.block(c, m, DisplayKit.tiny(new Vector3f(0, -3, 0)), true);
        parts.add(p);
    }

    /**
     * @param k    общий масштаб глаза (0.3 — вдали, 1 — полный)
     * @param gy   сдвиг по вертикали (-3 = под плоскостью разлома, +2.5 = спрятан за ней)
     * @param open раскрытие век 0..1
     * @param gx   смещение зрачка/радужки по x, gz — по z (взгляд)
     */
    void apply(DisplayKit kit, int dur, float k, float gy, float open, float gx, float gz) {
        for (Part p : parts) {
            float cx = p.cx, cz = p.cz, sz = p.sz;
            if (p.kind == GAZE) {
                cx += gx;
                cz += gz;
            } else if (p.kind >= LID_TOP) {
                float sign = p.kind == LID_TOP ? 1f : -1f;
                float bb = p.sz;
                sz = bb * (1 - open) + 0.02f;
                cz = sign * (bb * open + bb) / 2f;     // веко занимает [bb*open .. bb] с нужной стороны
            }
            Vector3f center = new Vector3f(cx * k, p.cy * k + gy, cz * k);
            Vector3f size = new Vector3f(p.sx * k, p.sy * k, sz * k);
            kit.apply(p.d, DisplayKit.box(center, IDENT, size), dur);
        }
    }

    void remove(DisplayKit kit) {
        for (Part p : parts) kit.kill(p.d);
        parts.clear();
    }
}
