package dev.hellbreach;

import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.function.IntConsumer;

/**
 * Одно событие целиком. Всё идёт по единому «таймлайну» (карта тик → действия + циклы), который тикает
 * ровно один BukkitRunnable. Точка удара фиксируется в конструкторе и не меняется.
 *
 * Фазы: трещины → раскрытие провала → глаз (вход/осмотр/уход) → пауза → щупалце (выход/замах/удар) →
 *       пауза → втягивание → закрытие разлома (осколки и трещины возвращаются) → уборка.
 */
final class RiftEvent {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private record Loop(int from, int to, IntConsumer body) {}
    private record CrackEnt(BlockDisplay d, Transformation from) {}
    private record ShardEnt(BlockDisplay d, CrackPattern.Shard sh, Quaternionf rest) {}
    private record HolePart(BlockDisplay d, float y, float size, float yaw, float thick) {}

    private final HellbreachPlugin plugin;
    private final Settings s;
    private final Player caster;
    private final World world;
    private final Location strike;     // ФИКСИРУЕТСЯ при активации
    private final Location center;     // центр разлома
    private final DisplayKit kit;
    private final Impact impact;
    private final Random rnd = new Random();
    private final Set<UUID> viewers = new HashSet<>();

    // таймлайн (абсолютные тики от начала анимации)
    private final int tc, openT, eyeStart, eyeInEnd, eyeHoldEnd, eyeOutEnd,
            tentStart, emergeEnd, windupEnd, strikeEnd, holdEnd, retractEnd, closeEnd, endTick;
    private final Map<Integer, List<Runnable>> actions = new HashMap<>();
    private final List<Loop> loops = new ArrayList<>();
    private BukkitTask task;
    private int tick;
    private boolean finished;

    // объекты сцены
    private CrackPattern pattern;
    private final List<CrackEnt> cracks = new ArrayList<>();
    private final List<ShardEnt> shards = new ArrayList<>();
    private final List<HolePart> hole = new ArrayList<>();
    private EyeRig eye;
    private TentacleRig tentacle;
    private float gazeX, gazeZ;

    RiftEvent(HellbreachPlugin plugin, Settings s, Player caster, Location strike) {
        this.plugin = plugin;
        this.s = s;
        this.caster = caster;
        this.world = strike.getWorld();
        this.strike = strike.clone();
        double ang = rnd.nextDouble() * Math.PI * 2;
        double cy = Math.min(strike.getY() + s.riftHeight, world.getMaxHeight() + 60);
        double cx = strike.getX() + Math.cos(ang) * s.riftOffset;
        double cz = strike.getZ() + Math.sin(ang) * s.riftOffset;
        if (!world.isChunkLoaded((int) Math.floor(cx) >> 4, (int) Math.floor(cz) >> 4)) {   // не грузим чанки синхронно
            cx = strike.getX();
            cz = strike.getZ();
        }
        this.center = new Location(world, cx, cy, cz);
        this.kit = new DisplayKit(s);
        this.impact = new Impact(plugin, s, kit);

        tc = s.tCrack;
        openT = (int) (tc * 0.55);
        eyeStart = tc;
        eyeInEnd = eyeStart + s.tEyeIn;
        eyeHoldEnd = eyeInEnd + s.tEyeHold;
        eyeOutEnd = eyeHoldEnd + s.tEyeOut;
        tentStart = eyeOutEnd + s.tGap;
        emergeEnd = tentStart + s.tEmerge;
        windupEnd = emergeEnd + s.tWindup;
        strikeEnd = windupEnd + s.tStrike;
        holdEnd = strikeEnd + s.tHold;
        retractEnd = holdEnd + s.tRetract;
        closeEnd = retractEnd + s.tClose;
        endTick = closeEnd + 12;
    }

    // ───────────────────────── запуск / завершение ─────────────────────────

    void start() {
        double r2 = s.viewerRadius * s.viewerRadius;
        for (Player p : world.getPlayers()) {
            if (p.getLocation().distanceSquared(strike) <= r2) viewers.add(p.getUniqueId());
        }
        // тяжёлая математика (сеть трещин, осколки) — асинхронно, без обращения к Bukkit API
        long seed = rnd.nextLong();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            CrackPattern p;
            try {
                p = CrackPattern.generate(seed, s.crackRadius, s.holeRadius, s.maxCracks, s.shardCount, s.crackWidth);
            } catch (Throwable t) {
                Bukkit.getScheduler().runTask(plugin, () -> fail(t));
                return;
            }
            final CrackPattern ready = p;
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (finished) return;
                pattern = ready;
                try {
                    begin();
                } catch (Throwable t) {
                    fail(t);
                }
            });
        });
    }

    /** Любой сбой на старте: лог + полная уборка, иначе plugin.busy() залипнет до перезагрузки. */
    private void fail(Throwable t) {
        plugin.getLogger().log(java.util.logging.Level.SEVERE, "Сбой запуска события — аварийная уборка", t);
        finish();
    }

    void abort() {
        finish();
    }

    private void finish() {
        if (finished) return;
        finished = true;
        if (task != null) task.cancel();
        impact.cancel();
        kit.removeAll();
        for (UUID id : viewers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.resetPlayerTime();
        }
        plugin.onFinished(this);
    }

    private void begin() {
        atmosphere();
        Vector3d rift = new Vector3d(center.getX(), center.getY(), center.getZ());
        Vector3d tip = new Vector3d(strike.getX(), strike.getY() - s.embed, strike.getZ());
        tentacle = new TentacleRig(kit, s, rift, tip, rnd.nextBoolean());

        planCracks();
        planHole();
        planEye();
        planTentacle();
        at(retractEnd, this::closeSky);

        task = new BukkitRunnable() {
            @Override
            public void run() {
                try {
                    tickOnce();
                } catch (Throwable t) {
                    plugin.getLogger().log(java.util.logging.Level.SEVERE, "Сбой события — аварийная уборка", t);
                    finish();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void tickOnce() {
        List<Runnable> list = actions.remove(tick);
        if (list != null) for (Runnable r : list) r.run();
        for (Loop l : loops) if (tick >= l.from() && tick < l.to()) l.body().accept(tick - l.from());
        tick++;
        if (tick >= endTick) finish();
    }

    private void at(int t, Runnable r) {
        actions.computeIfAbsent(Math.max(0, t), k -> new ArrayList<>()).add(r);
    }

    private void loop(int from, int to, IntConsumer body) {
        loops.add(new Loop(from, to, body));
    }

    // ───────────────────────── 1. раскол неба ─────────────────────────

    private void planCracks() {
        List<CrackPattern.Seg> segs = pattern.segs;
        int n = segs.size();
        int span = (int) (tc * 0.75);
        for (int i = 0; i < n; i++) {
            CrackPattern.Seg g = segs.get(i);
            at((int) ((long) i * span / Math.max(1, n)), () -> spawnCrack(g));     // рост трещин от центра к краям
        }
        at(0, () -> {
            s.play(center, "thunder", 0.6f);
            if (s.titles) {
                Title title = Title.title(
                        MM.deserialize("<gradient:#ffb347:#8b0000><bold>НЕБО РАСКОЛОТО</bold></gradient>"),
                        MM.deserialize("<gray><italic>…и Бездна ответила</italic></gray>"),
                        Title.Times.times(Duration.ofMillis(600), Duration.ofSeconds(3), Duration.ofSeconds(1)));
                for (UUID id : viewers) {
                    Player p = Bukkit.getPlayer(id);
                    if (p != null) p.showTitle(title);
                }
            }
        });
        for (int t = 4; t < tc; t += 7) {
            at(t, () -> s.play(randomCrackPoint(), "glass", 0.5f + rnd.nextFloat() * 0.4f));
        }
        // искры по трещинам — лёгкие партиклы, 3 штуки раз в 2 тика
        loop(0, retractEnd, i -> {
            if ((i & 1) != 0 || cracks.isEmpty()) return;
            for (int k = 0; k < 3; k++) {
                CrackEnt c = cracks.get(rnd.nextInt(cracks.size()));
                if (!c.d().isValid()) continue;
                DisplayKit.fx(world, Particle.ELECTRIC_SPARK, c.d().getLocation(), 3, 1, 0.5, 1, 0.2);
            }
        });
        // осколки появляются, пока трещины растут
        int base = (int) (tc * 0.3);
        for (int i = 0; i < pattern.shards.size(); i++) {
            CrackPattern.Shard sh = pattern.shards.get(i);
            at(base + i / 15, () -> spawnShard(sh));
        }
    }

    private Location randomCrackPoint() {
        CrackPattern.Seg g = pattern.segs.get(rnd.nextInt(pattern.segs.size()));
        return center.clone().add((g.x0() + g.x1()) / 2.0, 0, (g.z0() + g.z1()) / 2.0);
    }

    private void spawnCrack(CrackPattern.Seg g) {
        double mx = (g.x0() + g.x1()) / 2.0, mz = (g.z0() + g.z1()) / 2.0;
        Location loc = center.clone().add(mx, 0.15, mz);
        if (!world.isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) return;
        float dx = g.x1() - g.x0(), dz = g.z1() - g.z0();
        float len = (float) Math.hypot(dx, dz);
        Quaternionf rot = new Quaternionf().rotateY((float) Math.atan2(dx, dz));
        float w = g.width();
        Transformation from = DisplayKit.box(new Vector3f((float) (g.x0() - mx), 0, (float) (g.z0() - mz)), rot, new Vector3f(w, 0.3f, 0.02f));
        Transformation to = DisplayKit.box(new Vector3f(), rot, new Vector3f(w, 0.3f, len + 0.3f));
        BlockDisplay d = kit.block(loc, s.crackMat, from, true);
        cracks.add(new CrackEnt(d, from));
        at(tick + 2, () -> kit.apply(d, to, 7));          // вырастает из начальной точки в конечную
    }

    private void spawnShard(CrackPattern.Shard sh) {
        Location loc = center.clone().add(sh.x(), 0.2, sh.z());
        if (!world.isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) return;
        Quaternionf rest = new Quaternionf().rotateY(sh.yaw()).rotateX(sh.tilt());
        BlockDisplay d = kit.block(loc, s.shardMat, DisplayKit.box(new Vector3f(), rest, new Vector3f(0.01f)), true);
        ShardEnt se = new ShardEnt(d, sh, rest);
        shards.add(se);
        at(tick + 2, () -> kit.apply(d, DisplayKit.box(new Vector3f(), rest, new Vector3f(sh.sx(), 0.18f, sh.sz())), 10));
    }

    private void applyShard(ShardEnt se, float f, int dur) {
        CrackPattern.Shard sh = se.sh();
        Vector3f off = new Vector3f(sh.dx() * f, sh.dy() * f, sh.dz() * f);
        Quaternionf q = new Quaternionf(se.rest()).rotateAxis(sh.spin() * f, sh.ax(), sh.ay(), sh.az());
        kit.apply(se.d(), DisplayKit.box(off, q, new Vector3f(sh.sx(), 0.18f, sh.sz())), dur);
    }

    // ───────────────────────── провал ─────────────────────────

    private static Transformation holeTf(float y, float size, float yaw, float thick, float f) {
        float ff = Math.max(f, 0.02f);
        return DisplayKit.box(new Vector3f(0, y, 0), new Quaternionf().rotateY(yaw + ff * 0.52f),
                new Vector3f(size * ff, thick, size * ff));
    }

    private void planHole() {
        at(openT - 3, () -> {
            float R = (float) s.holeRadius;
            for (int k = 0; k < 3; k++) {        // три квадрата, повёрнутые на 30° → 12-лучевая «рваная» звезда
                float yaw = k * (float) (Math.PI / 6);
                addHole(false, -0.25f - k * 0.02f, R * 1.414f, yaw);
                addHole(true, -0.75f - k * 0.02f, R * 1.10f, yaw);
            }
        });
        at(openT, () -> {
            applyHole(1f, tc - openT);
            s.play(center, "open", 0.7f);
            for (ShardEnt se : shards) applyShard(se, 0.7f, 40);             // осколки отделяются от разлома
        });
        at(openT + 40, () -> {
            for (ShardEnt se : shards) applyShard(se, 1f, Math.max(1, retractEnd - (openT + 40)));  // медленный дрейф
        });
        // искры лавы из провала, пока он открыт
        loop(openT, retractEnd, i -> {
            if (i % 3 != 0) return;
            Location l = center.clone().add(0, -1.5, 0);
            DisplayKit.fx(world, Particle.FALLING_LAVA, l, 6, s.holeRadius * 0.7, 0.2, s.holeRadius * 0.7, 0);
        });
    }

    private void addHole(boolean glow, float y, float size, float yaw) {
        BlockDisplay d = kit.block(center, glow ? s.glowMat : s.holeMat, holeTf(y, size, yaw, 0.5f, 0f), glow);
        hole.add(new HolePart(d, y, size, yaw, 0.5f));
    }

    private void applyHole(float f, int dur) {
        for (HolePart p : hole) kit.apply(p.d(), holeTf(p.y(), p.size(), p.yaw(), p.thick(), f), dur);
    }

    // ───────────────────────── 2. глаз ─────────────────────────

    private void planEye() {
        int in1 = (int) (s.tEyeIn * 0.65), in2 = s.tEyeIn - in1;
        int out1 = (int) (s.tEyeOut * 0.3), out2 = s.tEyeOut - out1;

        at(eyeStart - 6, () -> {
            eye = new EyeRig();
            eye.build(kit, s, center);
        });
        at(eyeStart, () -> {
            eye.apply(kit, in1, 1f, -3f, 0f, 0f, 0f);              // растёт из точки с закрытыми веками
            s.play(center, "growl", 0.5f);
        });
        at(eyeStart + in1, () -> eye.apply(kit, in2, 1f, -3f, 1f, 0f, 0f));     // веки раскрываются
        for (int t = eyeStart; t < eyeHoldEnd; t += 20) at(t, () -> s.play(center, "heartbeat", 0.6f));

        // осматривается: взгляд переходит между зрителями, в конце — на точку удара
        for (int t = eyeInEnd; t < eyeHoldEnd - 16; t += 16) at(t, this::gazeAtViewer);
        at(eyeHoldEnd - 14, () -> gaze(strike.getX(), strike.getZ()));
        at(eyeInEnd + s.tEyeHold / 2, () -> eye.apply(kit, 4, 1f, -3f, 0.05f, gazeX, gazeZ));   // моргание
        at(eyeInEnd + s.tEyeHold / 2 + 5, () -> eye.apply(kit, 4, 1f, -3f, 1f, gazeX, gazeZ));

        // уходит: веки закрываются → глаз уменьшается и уезжает за плоскость разлома
        at(eyeHoldEnd, () -> eye.apply(kit, out1, 1f, -3f, 0f, gazeX, gazeZ));
        at(eyeHoldEnd + out1, () -> eye.apply(kit, out2, 0.3f, 2.5f, 0f, 0f, 0f));
        at(eyeOutEnd + 2, () -> {
            eye.remove(kit);
            eye = null;
        });
    }

    private void gazeAtViewer() {
        if (eye == null) return;
        List<Player> ps = new ArrayList<>();
        for (UUID id : viewers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.getWorld().equals(world)) ps.add(p);
        }
        if (ps.isEmpty()) gaze(strike.getX(), strike.getZ());
        else {
            Player p = ps.get(rnd.nextInt(ps.size()));
            gaze(p.getX(), p.getZ());
        }
    }

    private void gaze(double tx, double tz) {
        if (eye == null) return;
        double dx = tx - center.getX(), dz = tz - center.getZ();
        double len = Math.hypot(dx, dz);
        double k = Math.min(1.0, len / 60.0);
        gazeX = len < 1e-3 ? 0 : (float) (dx / len * k * s.eyeWidth / 2 * 0.34);
        gazeZ = len < 1e-3 ? 0 : (float) (dz / len * k * s.eyeHeight / 2 * 0.28);
        eye.apply(kit, 9, 1f, -3f, 1f, gazeX, gazeZ);
    }

    // ───────────────────────── 3-5. щупальце ─────────────────────────

    private void planTentacle() {
        int per = (int) Math.ceil(s.segments / 4.0);
        for (int b = 0; b < 4; b++) {
            int from = b * per, to = Math.min(s.segments, (b + 1) * per);
            at(tentStart - 12 + b, () -> tentacle.spawn(world, from, to));         // спавн порциями по тикам
        }
        loop(tentStart, retractEnd + 1, i -> tentStep(tentStart + i));

        at(tentStart, () -> s.play(center, "emerge", 0.6f));
        at(emergeEnd, () -> s.play(center, "windup", 0.5f));
        at(windupEnd, () -> s.play(center, "strike", 0.6f));
        at(strikeEnd, () -> impact.strike(strike.clone(), caster));              // ровно в сохранённую точку
        at(holdEnd, () -> s.play(center, "retract", 0.5f));
        at(retractEnd + 2, () -> tentacle.remove());
    }

    private void tentStep(int abs) {
        double sMax = tentacle.pathLength(), sE = 0.40 * sMax, sW = 0.22 * sMax;
        double sTip, wave;
        boolean fast = false;
        if (abs < emergeEnd) {                                   // медленный тяжёлый выход
            double p = (abs - tentStart + 1.0) / s.tEmerge;
            sTip = lerp(0, sE, easeInOutSine(p));
            wave = 1;
        } else if (abs < windupEnd) {                            // замах: отползает назад
            double p = (abs - emergeEnd + 1.0) / s.tWindup;
            sTip = lerp(sE, sW, easeInOutQuad(p));
            wave = 1 - 0.4 * p;
        } else if (abs < strikeEnd) {                            // удар: квадратичное ускорение
            double p = (abs - windupEnd + 1.0) / s.tStrike;
            sTip = lerp(sW, sMax, p * p);
            wave = 0.6 * (1 - p);
            fast = true;
        } else if (abs < holdEnd) {                              // вонзилось, оседает
            sTip = sMax;
            wave = 0;
            fast = abs - strikeEnd < 8;
        } else {                                                 // втягивание по тому же пути
            double p = (abs - holdEnd + 1.0) / s.tRetract;
            sTip = lerp(sMax, -2, easeInOutSine(p));
            wave = 0.7 * Math.min(1.0, p * 3);
        }
        if (!fast && (abs & 1) != 0) return;                     // медленные фазы — раз в 2 тика
        tentacle.step(sTip, wave, abs, fast ? 1 : 2);
    }

    // ───────────────────────── 6. закрытие ─────────────────────────

    private void closeSky() {
        s.play(center, "close", 1.2f);
        int holeDur = (int) (s.tClose * 0.45);
        applyHole(0f, holeDur);
        at(tick + holeDur + 2, () -> {
            for (HolePart p : hole) kit.kill(p.d());
            hole.clear();
        });

        int shardDur = (int) (s.tClose * 0.6);
        for (ShardEnt se : shards) applyShard(se, 0f, shardDur);              // осколки втягиваются на места
        at(tick + shardDur + 1, () -> {
            for (ShardEnt se : shards)
                kit.apply(se.d(), DisplayKit.box(new Vector3f(), se.rest(), new Vector3f(0.01f)), 6);
        });
        at(tick + shardDur + 8, () -> {
            for (ShardEnt se : shards) kit.kill(se.d());
            shards.clear();
        });

        int n = cracks.size(), span = (int) (s.tClose * 0.6);                 // трещины гаснут от краёв к центру
        for (int i = 0; i < n; i++) {
            CrackEnt c = cracks.get(i);
            int delay = 1 + (int) ((long) (n - 1 - i) * span / Math.max(1, n));
            at(tick + delay, () -> {
                kit.apply(c.d(), c.from(), 6);
                at(tick + 8, () -> kit.kill(c.d()));
            });
        }
        for (int k = 0; k < 6; k++) {
            float pitch = 1.0f + k * 0.15f;
            at(tick + 1 + k * (span / 6), () -> s.play(randomCrackPoint(), "glass", pitch));
        }
    }

    // ───────────────────────── мелочи ─────────────────────────

    private void atmosphere() {
        if (!s.atmosphere) return;
        for (UUID id : viewers) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) p.setPlayerTime(s.atmosphereTime, false);       // клиентское время; откат в finish()
        }
    }

    private static double lerp(double a, double b, double t) {
        return a + (b - a) * t;
    }

    private static double clamp01(double p) {
        return Math.max(0, Math.min(1, p));
    }

    private static double easeInOutSine(double p) {
        return -(Math.cos(Math.PI * clamp01(p)) - 1) / 2;
    }

    private static double easeInOutQuad(double p) {
        p = clamp01(p);
        return p < 0.5 ? 2 * p * p : 1 - Math.pow(-2 * p + 2, 2) / 2;
    }
}
