package dev.hellbreach;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

/** Фабрика временных Display-сущностей + математика трансформаций. Всё созданное здесь убирается removeAll(). */
final class DisplayKit {
    static final String TAG = "hellbreach_tmp";

    private final Settings s;
    private final Set<Display> live = new LinkedHashSet<>();

    DisplayKit(Settings s) {
        this.s = s;
    }

    BlockDisplay block(Location at, Material m, Transformation t, boolean fullbright) {
        return block(at, m.createBlockData(), t, fullbright);
    }

    BlockDisplay block(Location at, BlockData data, Transformation t, boolean fullbright) {
        BlockDisplay d = at.getWorld().spawn(at, BlockDisplay.class, e -> {
            e.setBlock(data);
            e.setTransformation(t);
            e.setPersistent(false);              // не сохраняем на диск — после краха мусора не останется
            e.addScoreboardTag(TAG);
            e.setViewRange(s.viewRange);
            e.setShadowRadius(0f);
            e.setShadowStrength(0f);
            if (fullbright) e.setBrightness(new Display.Brightness(15, 15));
        });
        live.add(d);
        return d;
    }

    /** Плавный переход к новой трансформации: клиент интерполирует сам, пакет шлётся один раз. */
    void apply(Display d, Transformation t, int dur) {
        if (d == null || !d.isValid()) return;
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(Math.max(0, dur));
        d.setTransformation(t);
    }

    void kill(Display d) {
        if (d == null) return;
        live.remove(d);
        if (d.isValid()) d.remove();
    }

    void removeAll() {
        for (Display d : new ArrayList<>(live)) {
            if (d.isValid()) d.remove();
        }
        live.clear();
    }

    /**
     * Куб размера size, повёрнутый на rot, центр которого лежит в точке center (локально от сущности).
     * Блок-дисплей рисуется от угла (0,0,0), поэтому центруем: T = center - rot * (size/2).
     */
    static Transformation box(Vector3f center, Quaternionf rot, Vector3f size) {
        Vector3f half = new Vector3f(size).mul(0.5f);
        rot.transform(half);
        Vector3f t = new Vector3f(center).sub(half);
        return new Transformation(t, new Quaternionf(rot), new Vector3f(size), new Quaternionf());
    }

    static Transformation tiny(Vector3f center) {
        return box(center, new Quaternionf(), new Vector3f(0.001f));
    }

    /** Партикл «всем видно издалека» (force=true). */
    static void fx(World w, Particle p, Location l, int count, double ox, double oy, double oz, double speed) {
        w.spawnParticle(p, l, count, ox, oy, oz, speed, null, true);
    }
}
