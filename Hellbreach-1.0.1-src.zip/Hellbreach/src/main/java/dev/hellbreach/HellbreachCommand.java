package dev.hellbreach;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.RayTraceResult;

import java.util.ArrayList;
import java.util.List;

final class HellbreachCommand implements CommandExecutor, TabCompleter {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private static final String PREFIX = "<gradient:#ff6a00:#7a0000><bold>HELLBREACH</bold></gradient> <dark_gray>›</dark_gray> ";

    private final HellbreachPlugin plugin;

    HellbreachCommand(HellbreachPlugin plugin) {
        this.plugin = plugin;
    }

    private static Component msg(String body) {
        return MM.deserialize(PREFIX + body);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("hellbreach.use")) {
            sender.sendMessage(msg("<red>Печать на вратах не признаёт тебя.</red>"));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("cancel")) {
            if (!sender.hasPermission("hellbreach.admin")) return deny(sender);
            plugin.abort();
            int n = plugin.sweep();
            sender.sendMessage(msg("<gray>Разлом запечатан. Убрано сущностей: <white>" + n + "</white>.</gray>"));
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("hellbreach.admin")) return deny(sender);
            plugin.reload();
            sender.sendMessage(msg("<gray>Свитки перечитаны.</gray>"));
            return true;
        }

        Player p = sender instanceof Player pl ? pl : null;
        Location target;
        try {
            if (args.length == 0) {
                if (p == null) return usage(sender);
                RayTraceResult rr = p.rayTraceBlocks(120);
                target = (rr != null && rr.getHitPosition() != null)
                        ? rr.getHitPosition().toLocation(p.getWorld())
                        : p.getLocation();
            } else if (args.length == 3 && p != null) {
                target = new Location(p.getWorld(), num(args[0]), num(args[1]), num(args[2]));
            } else if (args.length == 4) {
                World w = Bukkit.getWorld(args[0]);
                if (w == null) {
                    sender.sendMessage(msg("<red>Такого мира нет в летописях.</red>"));
                    return true;
                }
                target = new Location(w, num(args[1]), num(args[2]), num(args[3]));
            } else {
                return usage(sender);
            }
        } catch (NumberFormatException ex) {
            return usage(sender);
        }

        if (!target.getWorld().isChunkLoaded(target.getBlockX() >> 4, target.getBlockZ() >> 4)) {
            sender.sendMessage(msg("<red>Эта земля ещё не пробуждена — подойди ближе.</red>"));
            return true;
        }
        if (p != null) {
            long left = plugin.cooldownLeft(p);
            if (left > 0) {
                sender.sendMessage(msg("<red>Бездна ещё не отдышалась: <white>" + left + " с</white>.</red>"));
                return true;
            }
        }
        if (!plugin.launch(p, target)) {          // защита от повторного запуска
            sender.sendMessage(msg("<red>Небо уже расколото. Дождись, пока разлом затянется.</red>"));
            return true;
        }
        if (p != null) plugin.markCooldown(p);
        sender.sendMessage(msg("<gold>Печати сорваны.</gold> <gray>Цель: <white>" + target.getWorld().getName() + " "
                + target.getBlockX() + " " + target.getBlockY() + " " + target.getBlockZ() + "</white></gray>"));
        return true;
    }

    private boolean deny(CommandSender s) {
        s.sendMessage(msg("<red>Недостаточно силы.</red>"));
        return true;
    }

    private boolean usage(CommandSender s) {
        s.sendMessage(msg("<gray>/hellbreach</gray> <dark_gray>|</dark_gray> <gray>x y z</gray> <dark_gray>|</dark_gray> <gray>мир x y z</gray> <dark_gray>|</dark_gray> <gray>cancel</gray> <dark_gray>|</dark_gray> <gray>reload</gray>"));
        return true;
    }

    private static double num(String s) {
        return Double.parseDouble(s);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1 && sender.hasPermission("hellbreach.admin")) {
            for (String o : new String[]{"cancel", "reload"}) if (o.startsWith(args[0].toLowerCase())) out.add(o);
        }
        return out;
    }
}
