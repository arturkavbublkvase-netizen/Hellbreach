package dev.hellbreach;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * Чистая математика (без Bukkit API) — безопасно считается асинхронно.
 * Трещины: радиальные «молнии» с ветвлением. Осколки: плоские пластины вокруг провала.
 */
final class CrackPattern {
    /** Отрезок трещины в плоскости разлома (локальные координаты от центра). order — «глубина» для поэтапного роста. */
    record Seg(float x0, float z0, float x1, float z1, float width, int order) {}

    /** Осколок: место покоя, размер, поворот и вектор/вращение разлёта. */
    record Shard(float x, float z, float sx, float sz, float yaw, float tilt,
                 float dx, float dy, float dz, float spin, float ax, float ay, float az) {}

    final List<Seg> segs = new ArrayList<>();
    final List<Shard> shards = new ArrayList<>();

    private record Branch(double x, double z, double ang, double remain, int order, int gen, double width) {}

    static CrackPattern generate(long seed, double radius, double hole, int maxSegs, int shardCount, double baseWidth) {
        Random r = new Random(seed);
        CrackPattern p = new CrackPattern();

        ArrayDeque<Branch> q = new ArrayDeque<>();
        int mains = 9;
        for (int i = 0; i < mains; i++) {
            double a = i * Math.PI * 2 / mains + (r.nextDouble() - 0.5) * 0.5;
            q.add(new Branch(0, 0, a, radius * (0.7 + 0.3 * r.nextDouble()), 0, 0, baseWidth));
        }
        double step = Math.max(2.5, radius / 18.0);

        while (!q.isEmpty() && p.segs.size() < maxSegs) {
            Branch b = q.poll();
            double x = b.x(), z = b.z(), ang = b.ang(), travelled = 0;
            int order = b.order();
            while (travelled < b.remain() && p.segs.size() < maxSegs) {
                ang += (r.nextDouble() - 0.5) * 0.7;
                double len = step * (0.7 + 0.6 * r.nextDouble());
                double nx = x + Math.cos(ang) * len, nz = z + Math.sin(ang) * len;
                order++;
                p.segs.add(new Seg((float) x, (float) z, (float) nx, (float) nz, (float) b.width(), order));
                x = nx;
                z = nz;
                travelled += len;
                if (b.gen() < 3 && r.nextDouble() < 0.2) {
                    double side = r.nextBoolean() ? 1 : -1;
                    q.add(new Branch(x, z, ang + side * (0.5 + r.nextDouble() * 0.8),
                            (b.remain() - travelled) * (0.45 + 0.3 * r.nextDouble()),
                            order, b.gen() + 1, b.width() * 0.65));
                }
            }
        }
        p.segs.sort(Comparator.comparingInt(Seg::order));

        for (int i = 0; i < shardCount; i++) {
            double a = r.nextDouble() * Math.PI * 2;
            double inner = hole * 0.85, outer = Math.max(inner + 4, radius * 0.55);
            double d = inner + r.nextDouble() * (outer - inner);
            double out = 3 + r.nextDouble() * 8;
            double axA = r.nextDouble() * Math.PI * 2;
            p.shards.add(new Shard(
                    (float) (Math.cos(a) * d), (float) (Math.sin(a) * d),
                    (float) (2.5 + r.nextDouble() * 3.5), (float) (2.5 + r.nextDouble() * 3.5),
                    (float) (r.nextDouble() * Math.PI * 2), (float) ((r.nextDouble() - 0.5) * 0.4),
                    (float) (Math.cos(a) * out), (float) -(3 + r.nextDouble() * 14), (float) (Math.sin(a) * out),
                    (float) (0.6 + r.nextDouble() * 1.2),
                    (float) Math.cos(axA), 0.3f, (float) Math.sin(axA)));
        }
        return p;
    }
}
