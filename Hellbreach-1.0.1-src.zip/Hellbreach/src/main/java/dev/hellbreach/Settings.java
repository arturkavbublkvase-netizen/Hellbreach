package dev.hellbreach;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.SoundCategory;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Неизменяемый снимок config.yml: читается при старте и /hellbreach reload. */
final class Settings {
    // general
    final int cooldownSeconds;
    final double viewerRadius;
    final boolean titles, atmosphere;
    final int atmosphereTime;

    // rift
    final double riftHeight, riftOffset, crackRadius, holeRadius, crackWidth;
    final int maxCracks, shardCount;
    final float viewRange;
    final Material crackMat, shardMat, holeMat, glowMat;

    // eye
    final double eyeWidth, eyeHeight;
    final Material eyeScleraMat, eyeIrisMat, eyePupilMat, eyeLidMat;

    // tentacle
    final int segments, nodeEvery;
    final double baseWidth, tipWidth, embed, waveAmp, follow;
    final Material fleshMat, nodeMat;

    // timeline (ticks)
    final int tCrack, tEyeIn, tEyeHold, tEyeOut, tGap, tEmerge, tWindup, tStrike, tHold, tRetract, tClose;

    // impact
    final boolean blockDamage, fireExplodeEvent, breakContainers, scorch;
    final double craterRadius, craterSink, maxResistance, dropChance, scorchRadius, scorchFire;
    final int maxBlocks, blocksPerTick, debrisCount, shockTicks;
    final double shockRadius, damage, damageRadius, knockback;
    final Set<Material> protectedMats = EnumSet.noneOf(Material.class);
    final List<Material> scorchMats = new ArrayList<>();

    // sounds
    final float soundVolume;
    private final Map<String, String> sounds = new HashMap<>();

    Settings(FileConfiguration c) {
        cooldownSeconds = c.getInt("general.cooldown-seconds", 300);
        viewerRadius = c.getDouble("general.viewer-radius", 220.0);
        titles = c.getBoolean("general.titles", true);
        atmosphere = c.getBoolean("general.atmosphere.enabled", true);
        atmosphereTime = c.getInt("general.atmosphere.player-time", 12700);

        riftHeight = c.getDouble("rift.height", 115.0);
        riftOffset = c.getDouble("rift.horizontal-offset", 22.0);
        crackRadius = c.getDouble("rift.crack-radius", 62.0);
        holeRadius = c.getDouble("rift.hole-radius", 22.0);
        crackWidth = c.getDouble("rift.crack-width", 0.9);
        maxCracks = Math.max(20, c.getInt("rift.max-cracks", 220));
        shardCount = Math.max(0, c.getInt("rift.shard-count", 56));
        viewRange = (float) c.getDouble("rift.view-range", 10.0);
        crackMat = mat(c, "rift.materials.crack", Material.WHITE_CONCRETE);
        shardMat = mat(c, "rift.materials.shard", Material.LIGHT_BLUE_STAINED_GLASS);
        holeMat = mat(c, "rift.materials.hole", Material.BLACK_CONCRETE);
        glowMat = mat(c, "rift.materials.glow", Material.ORANGE_CONCRETE);

        eyeWidth = c.getDouble("eye.width", 40.0);
        eyeHeight = c.getDouble("eye.height", 20.0);
        eyeScleraMat = mat(c, "eye.materials.sclera", Material.YELLOW_CONCRETE);
        eyeIrisMat = mat(c, "eye.materials.iris", Material.ORANGE_CONCRETE);
        eyePupilMat = mat(c, "eye.materials.pupil", Material.BLACK_CONCRETE);
        eyeLidMat = mat(c, "eye.materials.lid", Material.BLACK_CONCRETE);

        segments = Math.max(12, c.getInt("tentacle.segments", 48));
        baseWidth = c.getDouble("tentacle.base-width", 4.0);
        tipWidth = c.getDouble("tentacle.tip-width", 1.4);
        embed = c.getDouble("tentacle.embed", 2.0);
        waveAmp = c.getDouble("tentacle.wave-amplitude", 3.2);
        follow = Math.min(1.0, Math.max(0.05, c.getDouble("tentacle.follow", 0.55)));
        nodeEvery = c.getInt("tentacle.node-every", 4);
        fleshMat = mat(c, "tentacle.materials.flesh", Material.NETHER_WART_BLOCK);
        nodeMat = mat(c, "tentacle.materials.node", Material.SHROOMLIGHT);

        tCrack = Math.max(20, c.getInt("timeline.cracks", 70));
        tEyeIn = Math.max(10, c.getInt("timeline.eye-in", 45));
        tEyeHold = Math.max(20, c.getInt("timeline.eye-hold", 60));
        tEyeOut = Math.max(10, c.getInt("timeline.eye-out", 40));
        tGap = Math.max(12, c.getInt("timeline.gap", 12));
        tEmerge = Math.max(20, c.getInt("timeline.tentacle-emerge", 90));
        tWindup = Math.max(10, c.getInt("timeline.windup", 36));
        tStrike = Math.max(4, c.getInt("timeline.strike", 14));
        tHold = Math.max(10, c.getInt("timeline.hold", 30));
        tRetract = Math.max(20, c.getInt("timeline.retract", 100));
        tClose = Math.max(20, c.getInt("timeline.close", 70));

        blockDamage = c.getBoolean("impact.block-damage", true);
        fireExplodeEvent = c.getBoolean("impact.fire-explode-event", true);
        breakContainers = c.getBoolean("impact.break-containers", false);
        craterRadius = c.getDouble("impact.crater-radius", 8.0);
        craterSink = c.getDouble("impact.crater-sink", 1.5);
        maxBlocks = Math.max(0, c.getInt("impact.max-blocks", 2200));
        blocksPerTick = Math.max(20, c.getInt("impact.blocks-per-tick", 350));
        maxResistance = c.getDouble("impact.max-block-resistance", 60.0);
        dropChance = c.getDouble("impact.drop-chance", 0.0);
        for (String n : c.getStringList("impact.protected-materials")) {
            Material m = Material.matchMaterial(n);
            if (m != null) protectedMats.add(m);
        }
        scorch = c.getBoolean("impact.scorch.enabled", true);
        scorchRadius = c.getDouble("impact.scorch.radius", 17.0);
        scorchFire = c.getDouble("impact.scorch.fire-chance", 0.0);
        for (String n : c.getStringList("impact.scorch.materials")) {
            Material m = Material.matchMaterial(n);
            if (m != null) scorchMats.add(m);
        }
        if (scorchMats.isEmpty()) scorchMats.add(Material.BLACKSTONE);
        damage = c.getDouble("impact.damage", 40.0);
        damageRadius = c.getDouble("impact.damage-radius", 22.0);
        knockback = c.getDouble("impact.knockback", 2.2);
        debrisCount = Math.max(0, c.getInt("impact.debris-count", 42));
        shockRadius = c.getDouble("impact.shockwave-radius", 30.0);
        shockTicks = Math.max(4, c.getInt("impact.shockwave-ticks", 16));

        soundVolume = (float) c.getDouble("sounds.volume", 8.0);
        ConfigurationSection sec = c.getConfigurationSection("sounds");
        if (sec != null) {
            for (String k : sec.getKeys(false)) {
                if (!k.equals("volume")) sounds.put(k, sec.getString(k, ""));
            }
        }
    }

    private static Material mat(FileConfiguration c, String path, Material def) {
        Material m = Material.matchMaterial(c.getString(path, def.name()));
        return m != null ? m : def;
    }

    /** Проигрывает звук по ключу из секции sounds (строковый id — устойчив к переименованиям enum Sound). */
    void play(Location at, String key, float pitch) {
        String id = sounds.get(key);
        if (id == null || id.isEmpty() || at.getWorld() == null) return;
        at.getWorld().playSound(at, id, SoundCategory.AMBIENT, soundVolume, pitch);
    }
}
