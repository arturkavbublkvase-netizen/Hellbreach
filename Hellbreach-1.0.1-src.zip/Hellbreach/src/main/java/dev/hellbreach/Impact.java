package dev.hellbreach;

import org.bukkit.Bukkit;
import org.bukkit.ExplosionResult;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;
import org.bukkit.GameMode;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

/**
 * Удар: урон существам, ударная волна, обломки и реальное разрушение блоков.
 * Разрушение: воронка (шум по краю) ≈ 10 TNT → синтетический EntityExplodeEvent (защита территорий) →
 * ломка порциями от центра наружу (без пика TPS) → обугливание поверхности.
 */
final class Impact {
    private record Cand(Block b, double d2) {}

    private static final class Deb {
        BlockDisplay e;
        Vector3d pos, vel;
        float size, rx, ry, spinX, spinY;
    }

    private final HellbreachPlugin plugin;
    private final Settings s;
    private final DisplayKit kit;
    private final Random rnd = new Random();
    private final List<BukkitTask> tasks = new ArrayList<>();

    Impact(HellbreachPlugin plugin, Settings s, DisplayKit kit) {
        this.plugin = plugin;
        this.s = s;
        this.kit = kit;
    }

    void cancel() {
        for (BukkitTask t : tasks) t.cancel();
        tasks.clear();
    }

    void strike(Location at, Player cause) {
        World w = at.getWorld();
        double R = s.craterRadius;

        // вспышка / огонь / дым
        DisplayKit.fx(w, Particle.EXPLOSION_EMITTER, at, 5, 3, 0.5, 3, 0);
        DisplayKit.fx(w, Particle.LAVA, at, 120, R * 0.5, 1, R * 0.5, 0);
        DisplayKit.fx(w, Particle.FLAME, at.clone().add(0, 1, 0), 400, R * 0.4, 0.5, R * 0.4, 0.55);
        DisplayKit.fx(w, Particle.LARGE_SMOKE, at.clone().add(0, 2, 0), 250, R * 0.5, 2, R * 0.5, 0.12);
        DisplayKit.fx(w, Particle.CLOUD, at.clone().add(0, 1, 0), 150, R * 0.6, 0.6, R * 0.6, 0.25);
        s.play(at, "impact", 0.55f);
        s.play(at, "impact2", 0.7f);

        damage(at);
        shockwave(at);
        crater(at, cause);
    }

    // ───────────────────────── урон ─────────────────────────

    private void damage(Location at) {
        World w = at.getWorld();
        double r = s.damageRadius;
        BoundingBox box = BoundingBox.of(at, r, r, r);          // один запрос, не цикл по тикам
        for (Entity e : w.getNearbyEntities(box)) {
            if (!(e instanceof LivingEntity le)) continue;
            if (le instanceof Player p && (p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR)) continue;
            double dist = le.getLocation().distance(at);
            if (dist > r) continue;
            double f = 1.0 - dist / r;
            le.damage(s.damage * f);
            Vector dir = le.getLocation().toVector().subtract(at.toVector());
            if (dir.lengthSquared() < 1e-4) dir = new Vector(0, 1, 0);
            dir.normalize();
            dir.setY(0.55);
            le.setVelocity(dir.multiply(s.knockback * f));
        }
    }

    // ───────────────────────── ударная волна ─────────────────────────

    private void shockwave(Location at) {
        World w = at.getWorld();
        tasks.add(new BukkitRunnable() {
            int t = 0;

            @Override
            public void run() {
                t++;
                double rad = 2 + (s.shockRadius - 2) * (t / (double) s.shockTicks);
                int pts = Math.min(120, Math.max(24, (int) (2 * Math.PI * rad / 1.1)));
                for (int i = 0; i < pts; i++) {
                    double a = i * 2 * Math.PI / pts;
                    double cx = Math.cos(a), cz = Math.sin(a);
                    double x = at.getX() + cx * rad, z = at.getZ() + cz * rad;
                    int bx = (int) Math.floor(x), bz = (int) Math.floor(z);
                    if (!w.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    int gy = w.getHighestBlockYAt(bx, bz);
                    w.spawnParticle(Particle.CLOUD, x, gy + 1.2, z, 0, cx, 0.08, cz, 0.45, null, true);
                    if ((i & 1) == 0) {
                        Block under = w.getBlockAt(bx, gy, bz);
                        if (!under.getType().isAir()) {
                            w.spawnParticle(Particle.BLOCK, x, gy + 1.2, z, 4, 0.35, 0.5, 0.35, 0.05, under.getBlockData(), true);
                        }
                    }
                    if (i % 4 == 0) w.spawnParticle(Particle.FLAME, x, gy + 1.0, z, 1, 0.1, 0.3, 0.1, 0.02, null, true);
                }
                if (t >= s.shockTicks) cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L));
    }

    // ───────────────────────── воронка ─────────────────────────

    private boolean breakable(Material m) {
        if (s.protectedMats.contains(m)) return false;
        if (m == Material.WATER || m == Material.LAVA) return true;
        return m.getBlastResistance() <= s.maxResistance;
    }

    private static double noise(int x, int y, int z) {
        long h = (x >> 1) * 73856093L ^ (y >> 1) * 19349663L ^ (z >> 1) * 83492791L;
        h = (h ^ (h >>> 13)) * 0x5bd1e995L;
        h ^= h >>> 15;
        return ((h & 0xFFFF) / 32767.5) - 1.0;
    }

    private void crater(Location at, Player cause) {
        if (!s.blockDamage || s.maxBlocks <= 0) return;
        World w = at.getWorld();
        double R = s.craterRadius;
        int cx = at.getBlockX(), cy = (int) Math.floor(at.getY() - s.craterSink), cz = at.getBlockZ();
        int r = (int) Math.ceil(R * 1.3) + 1;

        // 1) кандидаты в воронку
        List<Cand> crater = new ArrayList<>();
        for (int dx = -r; dx <= r; dx++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dz = -r; dz <= r; dz++) {
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > r * r) continue;
                    int bx = cx + dx, by = cy + dy, bz = cz + dz;
                    double lim = R * (1 + 0.22 * noise(bx, by, bz));
                    if (d2 > lim * lim) continue;
                    if (by < w.getMinHeight() || by >= w.getMaxHeight()) continue;
                    if (!w.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    Block b = w.getBlockAt(bx, by, bz);
                    Material m = b.getType();
                    if (m.isAir() || !breakable(m)) continue;
                    if (!s.breakContainers && b.getState(false) instanceof Container) continue;
                    crater.add(new Cand(b, d2));
                }
            }
        }
        crater.sort(Comparator.comparingDouble(Cand::d2));
        if (crater.size() > s.maxBlocks) crater.subList(s.maxBlocks, crater.size()).clear();   // жёсткий потолок

        // 2) обугливание поверхности вокруг
        List<Block> scorch = new ArrayList<>();
        if (s.scorch) {
            int sr = (int) Math.ceil(s.scorchRadius);
            double inner = R * 0.9;
            for (int dx = -sr; dx <= sr; dx++) {
                for (int dz = -sr; dz <= sr; dz++) {
                    double d = Math.hypot(dx, dz);
                    if (d <= inner || d > s.scorchRadius) continue;
                    double p = 1 - (d - inner) / Math.max(1.0, s.scorchRadius - inner);
                    if (rnd.nextDouble() > p * 0.9) continue;
                    int bx = cx + dx, bz = cz + dz;
                    if (!w.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    Block top = w.getHighestBlockAt(bx, bz);
                    Material m = top.getType();
                    if (!m.isSolid() || Tag.LEAVES.isTagged(m) || Tag.LOGS.isTagged(m) || !breakable(m)) continue;
                    if (!s.breakContainers && top.getState(false) instanceof Container) continue;
                    scorch.add(top);
                }
            }
        }

        // 3) защита территорий: прогоняем через EntityExplodeEvent (WorldGuard, GriefPrevention и т.д. вычеркнут блоки)
        if (s.fireExplodeEvent) {
            Set<Block> all = new LinkedHashSet<>();
            for (Cand c : crater) all.add(c.b());
            all.addAll(scorch);
            TNTPrimed src = w.spawn(at, TNTPrimed.class, e -> {
                e.setFuseTicks(1000);
                e.setPersistent(false);
                e.setVisibleByDefault(false);
                e.setSilent(true);
                if (cause != null) e.setSource(cause);
            });
            EntityExplodeEvent ev = new EntityExplodeEvent(src, at, new ArrayList<>(all), 0f, ExplosionResult.DESTROY);
            Bukkit.getPluginManager().callEvent(ev);
            src.remove();
            if (ev.isCancelled()) return;
            Set<Block> allowed = new HashSet<>(ev.blockList());
            crater.removeIf(c -> !allowed.contains(c.b()));
            scorch.removeIf(b -> !allowed.contains(b));
        }

        debris(at, crater);

        // 4) ломаем порциями от центра наружу
        ArrayDeque<Cand> queue = new ArrayDeque<>(crater);
        double shell = (R * 0.75) * (R * 0.75);
        tasks.add(new BukkitRunnable() {
            @Override
            public void run() {
                int done = 0;
                while (done < s.blocksPerTick && !queue.isEmpty()) {
                    Cand c = queue.poll();
                    Block b = c.b();
                    BlockData old = b.getBlockData();
                    if (s.dropChance > 0 && rnd.nextDouble() < s.dropChance) b.breakNaturally();
                    else b.setType(Material.AIR, c.d2() > shell);      // физику обновляем только на внешней оболочке
                    done++;
                    if (done % 15 == 0) {
                        w.spawnParticle(Particle.BLOCK, b.getLocation().add(0.5, 0.5, 0.5), 6, 0.5, 0.5, 0.5, 0.0, old, true);
                    }
                }
                if (queue.isEmpty()) {
                    for (Block b : scorch) {
                        b.setType(s.scorchMats.get(rnd.nextInt(s.scorchMats.size())), false);
                        if (s.scorchFire > 0 && rnd.nextDouble() < s.scorchFire) {
                            Block up = b.getRelative(0, 1, 0);
                            if (up.getType().isAir()) up.setType(Material.FIRE, false);
                        }
                    }
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L));
    }

    // ───────────────────────── обломки ─────────────────────────

    /** Летящие куски — BlockDisplay с баллистикой, мир они не меняют. Якорь — точка удара, движение трансформацией. */
    private void debris(Location at, List<Cand> crater) {
        if (s.debrisCount <= 0 || crater.isEmpty()) return;
        World w = at.getWorld();
        List<Deb> list = new ArrayList<>();
        for (int i = 0; i < s.debrisCount; i++) {
            Block b = crater.get(rnd.nextInt(crater.size())).b();
            double dx = b.getX() + 0.5 - at.getX(), dz = b.getZ() + 0.5 - at.getZ();
            double len = Math.max(0.5, Math.hypot(dx, dz));
            double sp = 0.35 + rnd.nextDouble() * 0.8;
            Deb d = new Deb();
            d.pos = new Vector3d(dx, b.getY() + 0.5 - at.getY(), dz);
            d.vel = new Vector3d(dx / len * sp + (rnd.nextDouble() - 0.5) * 0.3, 0.7 + rnd.nextDouble() * 0.9,
                    dz / len * sp + (rnd.nextDouble() - 0.5) * 0.3);
            d.size = 0.5f + rnd.nextFloat() * 0.9f;
            d.spinX = (rnd.nextFloat() - 0.5f) * 0.6f;
            d.spinY = (rnd.nextFloat() - 0.5f) * 0.6f;
            d.e = kit.block(at, b.getBlockData(),
                    DisplayKit.box(new Vector3f((float) d.pos.x, (float) d.pos.y, (float) d.pos.z), new Quaternionf(), new Vector3f(d.size)),
                    false);
            list.add(d);
        }
        tasks.add(new BukkitRunnable() {
            int age = 0;

            @Override
            public void run() {
                age++;
                Iterator<Deb> it = list.iterator();
                while (it.hasNext()) {
                    Deb d = it.next();
                    d.vel.y -= 0.08;
                    d.vel.mul(0.985, 1.0, 0.985);
                    d.pos.add(d.vel);
                    int bx = (int) Math.floor(at.getX() + d.pos.x), by = (int) Math.floor(at.getY() + d.pos.y), bz = (int) Math.floor(at.getZ() + d.pos.z);
                    boolean landed = d.vel.y < 0 && w.isChunkLoaded(bx >> 4, bz >> 4) && w.getBlockAt(bx, by, bz).getType().isSolid();
                    if (landed || age > 70) {
                        if (landed) DisplayKit.fx(w, Particle.LARGE_SMOKE, new Location(w, at.getX() + d.pos.x, at.getY() + d.pos.y + 0.5, at.getZ() + d.pos.z), 2, 0.2, 0.1, 0.2, 0.01);
                        kit.kill(d.e);
                        it.remove();
                        continue;
                    }
                    d.rx += d.spinX;
                    d.ry += d.spinY;
                    Quaternionf q = new Quaternionf().rotateXYZ(d.rx, d.ry, 0f);
                    kit.apply(d.e, DisplayKit.box(new Vector3f((float) d.pos.x, (float) d.pos.y, (float) d.pos.z), q, new Vector3f(d.size)), 1);
                }
                if (list.isEmpty()) cancel();
            }
        }.runTaskTimer(plugin, 1L, 1L));
    }
}
