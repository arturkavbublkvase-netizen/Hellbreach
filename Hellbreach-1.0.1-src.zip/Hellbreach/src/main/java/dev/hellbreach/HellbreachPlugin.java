package dev.hellbreach;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class HellbreachPlugin extends JavaPlugin implements Listener {
    private Settings settings;
    private RiftEvent active;                                   // одно событие на весь сервер
    private final Map<UUID, Long> cooldowns = new HashMap<>();  // очищается на PlayerQuitEvent

    @Override
    public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(getConfig());
        HellbreachCommand cmd = new HellbreachCommand(this);
        var pc = getCommand("hellbreach");
        if (pc != null) {
            pc.setExecutor(cmd);
            pc.setTabCompleter(cmd);
        }
        getServer().getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        abort();
        sweep();
    }

    Settings settings() {
        return settings;
    }

    void reload() {
        reloadConfig();
        settings = new Settings(getConfig());
    }

    boolean busy() {
        return active != null;
    }

    /** @return false, если предыдущая анимация ещё идёт. */
    boolean launch(Player caster, Location strike) {
        if (active != null) return false;
        active = new RiftEvent(this, settings, caster, strike);
        active.start();
        return true;
    }

    void abort() {
        if (active != null) active.abort();
    }

    void onFinished(RiftEvent e) {
        if (active == e) active = null;
    }

    long cooldownLeft(Player p) {
        if (p.hasPermission("hellbreach.bypass")) return 0;
        Long until = cooldowns.get(p.getUniqueId());
        return until == null ? 0 : Math.max(0, (until - System.currentTimeMillis() + 999) / 1000);
    }

    void markCooldown(Player p) {
        cooldowns.put(p.getUniqueId(), System.currentTimeMillis() + settings.cooldownSeconds * 1000L);
    }

    /** Аварийная чистка помеченных Display (на случай сбоя). */
    int sweep() {
        int c = 0;
        for (World w : getServer().getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e instanceof Display && e.getScoreboardTags().contains(DisplayKit.TAG)) {
                    e.remove();
                    c++;
                }
            }
        }
        return c;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        cooldowns.remove(e.getPlayer().getUniqueId());
    }
}
